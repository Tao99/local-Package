# windows系统打包成exe安装包


1,先把需要安装的包压缩成7z文件，替换成SRH-Provider-Installer-master.7z

2,根据实际情况修改 t.bat 项目名称以及版本信息(例如：项目名PMA， 版本号1.3.4)

3,双击 t.bat 即可